package com.example.demo.entity;
package com.dailycodebuffer.Springboot.tutorial.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class College {
	
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long CollegeId;
	 private String CollegeName;
	    private String CollegeAddress;
	    private String CollegeCode;
		public Long getCollegeId() {
			return CollegeId;
		}
		public void setCollegeId(Long CollegeId) {
			this.CollegeId = CollegeId;
		}
		public String getCollegeName() {
			return CollegeName;
		}
		public void setCollegeName(String CollegeName) {
			this.CollegeName = CollegeName;
		}
		public String getCollegeAddress() {
			return CollegeAddress;
		}
		public void setCollegeAddress(String CollegeAddress) {
			this.CollegeAddress = CollegeAddress;
		}
		public String getCollegeCode() {
			return CollegeCode;
		}
		public void setCollegeCode(String CollegeCode) {
			this.CollegeCode = CollegeCode;
		}
		
		public College() {
			super();
		}
	
		public College(Long departmentId, String CollegeName, String CollegeAddress, String CollegeCode) {
			
			this.CollegeId = CollegeId;
			this.CollegeName = CollegeName;
			this.CollegeAddress = CollegeAddress;
			this.CollegeCode = CollegeCode;
		}
		@Override
		public String toString() {
			return " [CollegeId=" + CollegeId + ", CollegeName=" + CollegeName
					+ ", CollegeAddress=" + CollegeAddress + ", CollegeCode=" + CollegeCode + "]";
		}
		
	
	
	
}

public class College {

}
