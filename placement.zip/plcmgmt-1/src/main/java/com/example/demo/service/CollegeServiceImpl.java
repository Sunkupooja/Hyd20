package com.example.demo.service;
package com.dailycodebuffer.Springboot.tutorial.service;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dailycodebuffer.Springboot.tutorial.entity.College;
//import com.dailycodebuffer.Springboot.tutorial.error.CollegeNotFoundException;
import com.dailycodebuffer.Springboot.tutorial.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService {

    @Autowired
    private CollegeRepository CollegeRepository;

    @Override
    public College saveCollege(College College) {s
        return CollegeRepository.save(College);
    }

    @Override
    public List<College> fetchCollegeList() {
        return CollegeRepository.findAll();
    }

   @Override
   public College fetchCollegeById(Long CollegeId) {
	   return CollegeRepository.findById(CollegeId).get();
   }
	
   @Override
   public void deleteCollegeById(Long CollegeId) {
	   CollegeRepository.deleteById(CollegeId);
   }


   @Override
   public College updateCollege(Long CollegeId, College College) {
	   College depDB = CollegeRepository.findById(CollegeId).get();

       if(Objects.nonNull(College.getCollegeName()) &&
       !"".equalsIgnoreCase(College.getDepartmentName())) {
           depDB.setCollegeName(College.getCollegeName());
       }

       if(Objects.nonNull(College.getCollegeCode()) &&
               !"".equalsIgnoreCase(College.getCollegeCode())) {
           depDB.setCollegeCodeCollege.getCollegeCode());
       }

       if(Objects.nonNullCollege.getCollegeAddress()) &&
               !"".equalsIgnoreCase(College.getCollegeAddress())) {
           depDB.setCollegeAddress(College.getCollegeAddress());
       }

       return CollegeRepository.save(depDB);
   }

    
    

}

public interface CollegeServiceImpl {

}
